package main.java.com.perfect8.blog.model;

public enum ProductStatus {
    ACTIVE,
    INACTIVE,
    OUT_OF_STOCKS
}
