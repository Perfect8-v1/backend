package main.java.com.perfect8.blog.model;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE,
    BLOCKER
}
