package main.java.com.perfect8.blog.model;
import jakarta.persistence.Entity; // For JPA entity mapping
import jakarta.persistence.GeneratedValue; // For automatic ID generation
import jakarta.persistence.GenerationType; // For specifying ID generation strategy
import jakarta.persistence.Id; // For marking the primary key
import jakarta.persistence.Column; // For custom column definitions
import java.math.BigDecimal;


public class Speaker {
}
