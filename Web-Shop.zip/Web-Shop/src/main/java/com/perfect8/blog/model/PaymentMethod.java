package main.java.com.perfect8.blog.model;

public enum PaymentMethod {
    PAYPAL,
    CREDIT_CARD,
    BANK_TRANSFER
}
