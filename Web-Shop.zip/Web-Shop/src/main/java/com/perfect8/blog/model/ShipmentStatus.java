package main.java.com.perfect8.blog.model;

public enum ShipmentStatus {
    PREPARING,
    SHIPPED,
    IN_TRANSIT,
    DELIVERED
}
